package mk.ukim.finki.wp.jan2025g2.model;

public enum ParkType {
    NATIONAL_RESERVE,
    WILDLIFE_SANCTUARY,
    MARINE_PROTECTED_AREA,
    BIOSPHERE_RESERVE
}
